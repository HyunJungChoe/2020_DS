#include<stdio.h>

#define n 8
#define m 500

void main()
{
	int path[8], path_cnt=0;

	int arr[8][8] = {
		{0,2,m,m,m,3,m,m},
		{2,0,4,1,m,m,m,m},
		{m,4,0,m,3,m,m,m},
		{m,1,m,0,3,m,2,m},
		{m,m,3,3,0,m,m,4},
		{3,m,m,m,m,0,6,m},
		{m,m,m,2,m,6,0,4},
		{m,m,m,m,4,m,4,0}};
		
		int i, j, k, s, e, min;
		int chk[8], distance[8], Dchk[8];
		
		printf("\n                   <���ͽ�Ʈ��(Dijkstra) �˰�����>                  \n");
		printf("\n �־��� �׷������� ������� �������� �Է��ϸ� �ִܰŸ��� �˷��ݴϴ�.");
		printf("\n +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		printf("\n +                                                                 +");
		printf("\n +                         [3]-------3-------[5]                   +");
		printf("\n +                          |                / (                   +");
		printf("\n +                          |               /   (                  +");
		printf("\n +                          4             3      4                 +");
		printf("\n +                          |           /         (                +");
		printf("\n +                          |          /           (               +");
		printf("\n +           [1]-----2-----[2]---1---[4]            [8]            +");
		printf("\n +            (                       (            /               +");
		printf("\n +              (                       (         /                +");
		printf("\n +                3                       2      4                 +");
		printf("\n +                 (                       (    /                  +");
		printf("\n +                  (                       (  /                   +");
		printf("\n +                  [6]----------6-----------[7]                   +");
		printf("\n +                                                                 +");
		printf("\n +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
		//////////////////////////////////////////////////////////////////////////////////// 
		
		
		printf("\n ������� �Է��Ͻÿ�. : ");
		scanf("%d", &s);
		printf(" �������� �Է��Ͻÿ�. : ");
		scanf("%d", &e);
		
		for(j=0; j<8; j++)
		{
			chk[j] = 0;
			distance[j] = m;
		}
		
		distance[s-1] = 0;
		
		for(i=0; i<8; i++)
		{
			min = m;
			for(j=0; j<8; j++)
			{
				if(chk[j]==0 && distance[j]<min)   {
					k = j;
					min = distance[j];
				}
			}
			
			chk[k] = 1;
			
			if(min==m) break;
			
			for(j=0; j<8; j++)
			{
				if(distance[j] > distance[k] + arr[k][j])
				{
					distance[j] = distance[k] + arr[k][j];
					Dchk[j]=k;
				}
			}
		}
		printf("\n %d���� ����Ͽ�, %d�� ���� �ִ� �Ÿ��� %d�Դϴ�.\n", s, e, distance[e-1]);
		k=e-1;
		while(1)
		{
			path[path_cnt++]=k;
			if(k==s-1)break;
			k=Dchk[k];
		}
		printf(" ��δ� : ");
		for(i=path_cnt-1;i>=1;i--)
		{
			printf("%d -> ",path[i]+1);
		}
		printf("%d�Դϴ�",path[i]+1);
}

