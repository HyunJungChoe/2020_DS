#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<Windows.h>
#include<time.h>
#include<conio.h>

#define col GetStdHandle(STD_OUTPUT_HANDLE)
#define RED SetConsoleTextAttribute( col,0x000c ) //������ 
#define BLUE SetConsoleTextAttribute( col,0x0001 | 0x0008) //�Ķ��� 
#define HIGH SetConsoleTextAttribute( col,0x00a) // ����
#define WHITE SetConsoleTextAttribute( col,0x000f) // ���
#define SKY SetConsoleTextAttribute( col, 0x000b) //�ϴû�
#define YELLOW SetConsoleTextAttribute( col, 0x000e) //�����
#define HIG SetConsoleTextAttribute( col, 0x000d) //����
#define VIO SetConsoleTextAttribute( col,0x0001 | 0x0008 |0x000c) //���� 

void gotoxy(int x, int y)
{
	COORD	Pos = {x, y} ;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos) ;
}

void main()
{
	int x,y;
	int b_x=-1;
	int b_y=-1;
	int i,h;
	
	int s_x=1, s_y=1;
	int e_x[2]={5, 20}, e_y[2]={20,5};
		
	for(i=0;i<2;i++)
	{
	
		for(h=0;h<50;h++)
		{	
			x=s_x+(e_x[i]-s_x)*h/50; //����
			y=s_y+(e_y[i]-s_y)*h/50;
			if(b_x == x && b_y==y)
				continue;	
			Sleep(50);
			gotoxy(x, y);
			if((h & 0x1) !=0)
				YELLOW;
			else
				RED;
			putch(31);

			b_x=x;
			b_y=y;
		}

		s_x=x;
		s_y=y;
	//	printf("-- %d %d --\n", x, y);
	}	
	gotoxy(10,20);
	puts("Bye");

	
}




